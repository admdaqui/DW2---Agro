const express = require("express");

const app = express();

app.use('/bscss', express.static('./node_modules/bootstrap/dist/css'));
app.use('/bsjs', express.static('./node_modules/bootstrap/dist/js'));
app.use('/popperjs', express.static('./node_modules/@popperjs/core/dist/umd'));
app.use('/jquery', express.static('./node_modules/jquery/dist'));
app.use('/img', express.static(__dirname + '/src/publico/img'));
app.use('/css', express.static(__dirname + '/src/publico/css'));

const PORTA = process.env.PORT || 8081;
app.listen(PORTA,function(){
    console.log('Servidor rodando na porta 8081');
});

app.get('/',function(req, res){
    res.sendFile(__dirname + '/src/views/home.html');
});